# Copyright (c) Microsoft. All rights reserved. Licensed under the MIT license. See LICENSE.txt in the project root for license information.
import requests
import uuid
import json
from flask import jsonify


graph_endpoint = 'https://graph.microsoft.com/v1.0{0}'

# Generic API Sending
def make_api_call(method, url, token, payload = None, parameters = None):
    # Send these headers with all API calls
    headers = { 'User-Agent' : 'python_tutorial/1.0',
                'Authorization' : 'Bearer {0}'.format(token),
                'Accept' : 'application/json',
                'Prefer': 'outlook.timezone=\"India Standard Time\"'}
                
    # Use these headers to instrument calls. Makes it easier
    # to correlate requests and responses in case of problems
    # and is a recommended best practice.
    request_id = str(uuid.uuid4())
    instrumentation = { 'client-request-id' : request_id,
                        'return-client-request-id' : 'true' }
                        
    headers.update(instrumentation)
    
    response = None
    
    if (method.upper() == 'GET'):
        response = requests.get(url, headers = headers, params = parameters)
    elif (method.upper() == 'DELETE'):
        requests.delete(url, headers = headers, params = parameters)
        
    elif (method.upper() == 'PATCH'):
        headers.update({ 'Content-Type' : 'application/json' })
        response = requests.patch(url, headers = headers, data = json.dumps(payload), params = parameters)
    elif (method.upper() == 'POST'):
        headers.update({ 'Content-Type' : 'application/json' })
        print("inside post")
        response = requests.post(url, headers = headers, data = json.dumps(payload), params = parameters)
        
    return response

def get_me(access_token):
  get_me_url = graph_endpoint.format('/me')

  # Use OData query parameters to control the results
  #  - Only return the displayName and mail fields
  query_parameters = {'$select': 'displayName,mail'}

  r = make_api_call('GET', get_me_url, access_token, "", parameters = query_parameters)

  return r.json()
  if (r.status_code == requests.codes.ok):
    da=r.json()
    dat=json.dumps(da)
    print(da)
    return r.json()
  else:
    return "{0}: {1}".format(r.status_code, r.text)

def get_messages(access_token):
  get_messages_url = graph_endpoint.format('/me/mailfolders/inbox/messages')
  
  # Use OData query parameters to control the results
  #  - Only first 10 results returned
  #  - Only return the ReceivedDateTime, Subject, and From fields
  #  - Sort the results by the ReceivedDateTime field in descending order
  query_parameters = {'$top': '10',
                      '$select': 'receivedDateTime,subject,from',
                      '$orderby': 'receivedDateTime DESC'}
                      
  r = make_api_call('GET', get_messages_url, access_token, parameters = query_parameters)
  
  return r.json()
  if (r.status_code == requests.codes.ok):
    return r.json()
  else:
    return "{0}: {1}".format(r.status_code, r.text)
    
def get_events(access_token, isOrganizer =None, startTime=None,endTime=None):
  get_events_url = graph_endpoint.format('/me/events')
  
  # Use OData query parameters to control the results
  #  - Only first 10 results returned
  #  - Only return the Subject, Start, and End fields
  #  - Sort the results by the Start field in ascending order

  if isOrganizer==True:
    get_events_url=get_events_url+"?startdatetime="+startTime+"&enddatetime="+endTime+"&$select=id,subject,organizer,start,end,location&filter=(isOrganizer eq true)"
  else:
    get_events_url=get_events_url+"?startdatetime="+startTime+"&enddatetime="+endTime+"&$select=id,subject,organizer,start,end,location"
  print("get_events_url:"+get_events_url)
  r = make_api_call('GET', get_events_url, access_token)

  
  
  if (r.status_code == requests.codes.ok):
    return r.json()
  else:
    return r.json()
    #return "{0}: {1}".format(r.status_code, r.text)


def get_calenderView(access_token, isOrganizer =None, startTime=None,endTime=None):
  get_calendarView_url = graph_endpoint.format('/me/calendar/calendarView')
  
  # Use OData query parameters to control the results
  #  - Only first 10 results returned
  #  - Only return the Subject, Start, and End fields
  #  - Sort the results by the Start field in ascending order

  if isOrganizer==True:
    get_calendarView_url=get_calendarView_url+"?startdatetime="+startTime+"&enddatetime="+endTime+"&$select=id,subject,organizer,start,end,location&filter=(isOrganizer eq true)"
  else:
    get_calendarView_url=get_calendarView_url+"?startdatetime="+startTime+"&enddatetime="+endTime+"&$select=id,subject,organizer,start,end,location"
  print("get_calendarView_url:"+get_calendarView_url)
  r = make_api_call('GET', get_calendarView_url, access_token)

  
  if (r.status_code == requests.codes.ok):
    return r.json()
  else:
    print("res:"+json.dumps(r.json()))
    return r.json()

def cancel_event(access_token, event_id):
  delete_event_url = graph_endpoint.format('/me/events/'+event_id)
  print('delete_event_url:'+delete_event_url)
  make_api_call('DELETE', delete_event_url, access_token)
 

def get_contacts(access_token):
  get_contacts_url = graph_endpoint.format('/me/contacts')
  
  # Use OData query parameters to control the results
  #  - Only first 10 results returned
  #  - Only return the GivenName, Surname, and EmailAddresses fields
  #  - Sort the results by the GivenName field in ascending order
  query_parameters = {'$top': '10',
                      '$select': 'givenName,surname,emailAddresses',
                      '$orderby': 'givenName ASC'}
                      
  r = make_api_call('GET', get_contacts_url, access_token, parameters = query_parameters)
  
  return r.json()
  if (r.status_code == requests.codes.ok):
    return r.json()
  else:
    return "{0}: {1}".format(r.status_code, r.text)

def create_event(access_token,eventJson):
  print("create_event called, eventJson::"+json.dumps(eventJson))
  get_events_url = graph_endpoint.format('/me/events')
            
  r = make_api_call('POST', get_events_url, access_token, payload =eventJson)
  
  return r.json()
  if (r.status_code == requests.codes.ok):
    print("r suc:")
    return r.json()
  else:
    print("r err:")
    return "{0}: {1}".format(r.status_code, r.text)

def reschedule_event(access_token,event_id, eventJson):
  print("reschedule_my_event called")
  reschedule_event_url = graph_endpoint.format('/me/events/'+event_id)
            
  r = make_api_call('PATCH', reschedule_event_url, access_token, payload =eventJson)

  return r.json()
  if (r.status_code == requests.codes.ok):
    print("r suc:")
    return r.json()
  else:
    print("r err:")
    return "{0}: {1}".format(r.status_code, r.text)

def get_user_by_email(access_token,mail):
  print("get_user_by_email called")
  
  user_by_mail_url = graph_endpoint.format('/users/'+mail)
  query_parameters = {'$top': '10',
                      '$select': 'id,displayName,mail',
                      '$orderby': 'displayName ASC'}        
  r = make_api_call('GET', user_by_mail_url, access_token, parameters=query_parameters)

  return r.json()
  if (r.status_code == requests.codes.ok):
    print("r suc:")
    return r.json()
  else:
    print("r err:")
    return "{0}: {1}".format(r.status_code, r.text)

def send_mail(access_token,message_json):
  print("send_mail called")
  send_mail_url = graph_endpoint.format('/me/sendMail')
            
  r=make_api_call('POST', send_mail_url, access_token, payload =message_json)
  return r

    
    
