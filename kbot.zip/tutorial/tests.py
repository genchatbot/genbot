
import json
import os
import datetime
import time

def getDuration():
 events={}
 events['values']={"id":"1"};
 if(len(events['values'])>0):
   print("true")
 else:
   print("false")
 print("called")
 duration="1hr"
 
 duration=duration.replace(" ", "").lower()
 
 print("duration"+duration)
 first_h=duration.find('h')
 hr={}
 mins={}
 totalMins=0
 if first_h>0:
  hr=duration[0:first_h]
 
 if "m" in duration:
  if "rs" in duration:
   mins=duration[duration.find('rs')+2:duration.find('m')]
  else:
   mins=duration[duration.find('r')+1:duration.find('m')]

 if hr:
  totalMins=(int(hr)*60)
 if mins:
  totalMins=totalMins+int(mins)
 print("totalmins:"+str(totalMins))

getDuration();