import json
import os
import datetime
import time


def get_event_json(eventObj):
  full_path = os.path.realpath(__file__)
  
  with open(os.path.dirname(full_path)+'/event.json') as json_file:  
    eventJson = json.load(json_file)
    
    print("eventJson loaded:"+json.dumps(eventJson))
    eventJson['start']={'dateTime':eventObj['startTime'],'timeZone':eventObj['timeZone']}
    eventJson['end']={'dateTime':eventObj['endTime'],'timeZone':eventObj['timeZone']}
    eventJson['subject']=eventObj['subject']
    eventJson['body']['content']=eventObj['content']
    print("eventJson in utils.py..:"+json.dumps(eventJson))

    for att in eventObj['attendees']:
     attende={}
     attende['type']=att['type']
     attende['emailAddress'] = {}
     attende['emailAddress']['address'] = att['mail']
     attende['emailAddress']['name'] = att['name']
     eventJson['attendees'].append(attende)
    
    location=eventObj['location'].lower()
    if (location=="kalam") or (location=="elon"):
      locMail=location+"@suri44.onmicrosoft.com"
      eventJson['location']['locationType'] = "conferenceRoom"
      eventJson['location']['locationEmailAddress']=locMail
      attende={}
      attende['type']="resource"
      attende['emailAddress'] = {}
      attende['emailAddress']['address'] = locMail
      attende['emailAddress']['name'] = location
      eventJson['attendees'].append(attende)

    eventJson['location']['displayName'] = eventObj['location']

    print("eventJson:::::"+json.dumps(eventJson))
    return eventJson

def get_message_json(messageObj):
  full_path = os.path.realpath(__file__)
  
  with open(os.path.dirname(full_path)+'/message.json') as json_file:  
    messageJson = json.load(json_file)
    
    print("messageJson loaded:"+json.dumps(messageJson))
    messageJson['message']['subject']=messageObj['subject']
    messageJson['message']['body']['content']=messageObj['content']

    for re in messageObj['toRecipients']:
     print('re:'+re)
     recp={}
     recp['emailAddress'] = {}
     recp['emailAddress']['address'] = re
     messageJson['message']['toRecipients'].append(recp)
    
    print("messageJson:::::"+json.dumps(messageJson))
    return messageJson

def get_token():
  full_path = os.path.realpath(__file__)
  
  with open(os.path.dirname(full_path)+'/token.json') as json_file:  
    tokenJson = json.load(json_file)
    return tokenJson['token']

def write_token(access_token):
  full_path = os.path.realpath(__file__)
  
  with open(os.path.dirname(full_path)+'/token.json') as json_file:  
    tokenJson = json.load(json_file)
    tokenJson['token'] =access_token
    json.dump(tokenJson, json_file)

def getReadablEventDetails(ev):
  event={}
  event['id']=ev['id']
  event['subject']=ev['subject']
  if ev['organizer']['emailAddress']['name']:
    event['organizer']=ev['organizer']['emailAddress']['name']
  else:
    event['organizer']=ev['organizer']['emailAddress']['address']
  isoStartTime=ev['start']['dateTime']
  startTime=isoStartTime[0:19]
  event['startTime']=startTime
  isoEndTime=ev['end']['dateTime']
  #endTime=datetime.datetime.strptime(isoEndTime, '%Y-%m-%dT%H:%M:%S.%f')
  endTime = isoEndTime[0:19]
  event['endTime']=endTime
  event['location']=ev['location']['displayName']
  return event

def getDurationInMins(duration):
 duration=duration.replace(" ", "")
 duration=duration.replace(" ", "").lower()
 hr={}
 mins={}
 totalMins=0
 first_h=duration.find('h')
 if first_h>0:
  hr=duration[0:first_h]
 
 if "m" in duration:
  if "rs" in duration:
   mins=duration[duration.find('rs')+2:duration.find('m')]
  else:
   mins=duration[duration.find('r')+1:duration.find('m')]

 if hr:
  totalMins=(int(hr)*60)

 if mins:
  totalMins=totalMins+int(mins)
 
 return int(totalMins)


def get_message_json(messageObj):
  full_path = os.path.realpath(__file__)
  
  with open(os.path.dirname(full_path)+'/message.json') as json_file:  
    messageJson = json.load(json_file)
    
    print("messageJson loaded:"+json.dumps(messageJson))
    messageJson['message']['subject']=messageObj['subject']
    messageJson['message']['body']['content']=messageObj['content']

    for re in messageObj['toRecipients']:
     print('re:'+re)
     re=re.lower()
     if ("hr" in re) or ("human resource"):
       re="hr@suri44.onmicrosoft.com"
     if ("admin" in re):
       re="admin@suri44.onmicrosoft.com"
     recp={}
     recp['emailAddress'] = {}
     recp['emailAddress']['address'] = re
     messageJson['message']['toRecipients'].append(recp)
    
    print("messageJson:::::"+json.dumps(messageJson))
    return messageJson

def get_res_event_json(startTime,endTime):
  full_path = os.path.realpath(__file__)
  
  with open(os.path.dirname(full_path)+'/resevent.json') as json_file:  
    eventJson = json.load(json_file)
    timeZone = "India Standard Time"
    print("eventJson loaded:"+json.dumps(eventJson))
    eventJson['start']={'dateTime':startTime,'timeZone':timeZone}
    eventJson['end']={'dateTime':endTime,'timeZone':timeZone}
    return eventJson

   
   