# Copyright (c) Microsoft. All rights reserved. Licensed under the MIT license. See LICENSE.txt in the project root for license information.
from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from tutorial.authhelper import get_signin_url, get_token_from_code, get_access_token
from tutorial.outlookservice import get_me, get_my_messages, get_events, get_my_contacts , create_my_event, cancel_my_event,reschedule_my_event, get_user_by_email, send_mail
from tutorial.utils import get_event_json, get_message_json
import time
import json
import datetime
import os
import requests

# Create your views here.
def login():
    print('login called')

def get_cancel_eventId():
    print('login called')
    
def get_create_event_data():
  now = datetime.datetime.now()
  now_plus_10 = now + datetime.timedelta(minutes = 10)
  now_plus_30 = now + datetime.timedelta(minutes = 30)
  timeZone = "India Standard Time"
  startTime = now_plus_10.isoformat()
  endTime =now_plus_30.isoformat()
  print('startTime:'+startTime)

  event={}
  event['subject']="Testing meeting";
  attendee1={'name':'varsha sahu','mail':'varsha.sahu@suri44.onmicrosoft.com','type':'required'}
  attendee2={'name':'user one','mail':'user1@suri44.onmicrosoft.com','type':'optional'}
  event['attendees']=[]
  event['attendees'].append(attendee1)
  event['attendees'].append(attendee2)
  event['startTime']=startTime
  event['endTime']=endTime
  event['timeZone']=timeZone
  event['location']="my desk";
  
  return event

def get_send_mail_data():
  
  message={}
  message['subject']="Testing meeting mail";
  message['content']="Testing content mail";
  toRecipients={'varsha.sahu@suri44.onmicrosoft.com','user1@suri44.onmicrosoft.com'}
  message['toRecipients']=toRecipients
  return message

def home(request):
  print("in home")
  redirect_uri = request.build_absolute_uri(reverse('tutorial:gettoken'))
  sign_in_url = get_signin_url(redirect_uri)
  context = { 'signin_url': sign_in_url }
  print("in home sign_in_url"+sign_in_url)
  #r = requests.post(sign_in_url)
  
  return render(request, 'tutorial/home.html', context)
  
def gettoken(request):
  print("in gettoken")
  
  auth_code = request.GET['code']
  redirect_uri = request.build_absolute_uri(reverse('tutorial:gettoken'))
  token = get_token_from_code(auth_code, redirect_uri)
  access_token = token['access_token']
  user = get_me(access_token)
   
  eventObj = get_create_event_data()
  print("eventObj:"+json.dumps(eventObj))
  eventJson = get_event_json(eventObj)
  

  print('access_token::'+access_token)
  create_my_event(access_token,eventJson)

  refresh_token = token['refresh_token']
  expires_in = token['expires_in']

  # expires_in is in seconds
  # Get current timestamp (seconds since Unix Epoch) and
  # add expires_in to get expiration time
  # Subtract 5 minutes to allow for clock differences
  expiration = int(time.time()) + expires_in - 300
  
  # Save the token in the session
  request.session['access_token'] = access_token
  request.session['refresh_token'] = refresh_token
  request.session['token_expires'] = expiration

  return HttpResponseRedirect(reverse('tutorial:mail'))
  
def mail(request):
  access_token = get_access_token(request, request.build_absolute_uri(reverse('tutorial:gettoken')))
  # If there is no token in the session, redirect to home
  if not access_token:
    return HttpResponseRedirect(reverse('tutorial:home'))
  else:
    messages = get_my_messages(access_token)
    context = { 'messages': messages['value'] }
    return render(request, 'tutorial/mail.html', context)
    
def events(request):
  access_token = get_access_token(request, request.build_absolute_uri(reverse('tutorial:gettoken')))
  # If there is no token in the session, redirect to home
  if not access_token:
    return HttpResponseRedirect(reverse('tutorial:home'))
  else:
    #myHostedEvents = get_events(access_token,isOrganizer=True)
    events = get_events(access_token,isOrganizer=True)
    ev=events['value'][0]
    event_id=ev['id']
    print('event_id:'+event_id)

    #cancel_my_event(access_token,event_id)

    reschedule_event_json={'subject':'reschedule event subject test'}
    #reschedule_my_event(access_token,event_id,reschedule_event_json)
    
    mail="varsha.sahu@suri44.onmicrosoft.com"
    #user=get_user_by_email(access_token,mail)
    #print('user::'+json.dumps(user))

    mail="user1@suri44.onmicrosoft.com"
    #user=get_user_by_email(access_token,mail)
    #print('user::'+json.dumps(user))


    messageObj=get_send_mail_data()
    message_json=get_message_json(messageObj)
    send_mail(access_token,message_json)

    context = { 'events': events['value'] }
    return render(request, 'tutorial/events.html', context)
    
def contacts(request):
  access_token = get_access_token(request, request.build_absolute_uri(reverse('tutorial:gettoken')))
  # If there is no token in the session, redirect to home
  if not access_token:
    return HttpResponseRedirect(reverse('tutorial:home'))
  else:
    contacts = get_my_contacts(access_token)
    context = { 'contacts': contacts['value'] }
    return render(request, 'tutorial/contacts.html', context)
