import warnings
import json
import io
import os
import copy
import subprocess
import requests

import numpy as np
import collections
from pprint import pprint
import datetime

from pyo365 import Account

from de2 import load_from_file, DialogEngine, Context
from de2.domain import Plugin
from de2.constants import *

from de2.domain import Plugin
from flask import jsonify

from tutorial.authhelper import get_signin_url, get_token_from_code, get_access_token
from tutorial.outlookservice import get_me, get_messages, get_events, get_contacts , create_event ,get_calenderView
from tutorial.outlookservice import cancel_event,reschedule_event, get_user_by_email, send_mail
from tutorial.utils import get_event_json, get_message_json, get_token , getReadablEventDetails, getDurationInMins, get_message_json, get_res_event_json
import time

##########################################################################################################################
def getFormattedDateTime(datetimestr):
      time={}
      new_timestr=datetimestr[0:19]
      print('inside custom plugin new_timestr: '+new_timestr)
      date_time_obj = datetime.datetime.strptime(new_timestr, '%Y-%m-%d %H:%M:%S')
      print('Date:', date_time_obj.date())  
      print('Time:', date_time_obj.time())  
      print('Date-time:', date_time_obj)
      utcStartTime = date_time_obj + datetime.timedelta(minutes = -330)
      utcEndTime = utcStartTime + datetime.timedelta(minutes = 1440)
      time['startTime']=utcStartTime.isoformat()
      time['endTime']=utcEndTime.isoformat()
      
      return time

def get_my_hosted_events(self,params,context,node_id,action):
    
    print('get_my_events meeting_cancel_datetime:'+params['meeting_cancel_datetime'])
    time=getFormattedDateTime(params['meeting_cancel_datetime'])
    print('get_my_events params meeting_cancel_datetime'+params['meeting_cancel_datetime'])
    isOrganizer=True
    events=get_calenderView(get_token(), isOrganizer, time['startTime'],time['endTime'])
    
    if ("400" in events)  or ("error" in events):
           print("error occured in get_my_hosted_events:"+events['error']['message'])
           context.output.append("error occured in get_all_event:"+events['error']['message'])
    
    elif(len(events['value'])>0):
      result_dict = {}
      result_dict['action'] = action
      result_dict['result'] = {}
      result_dict['result']['result_type'] = 'qa'
      result_dict['result']['qa'] = []
      eventNo=1
    #for index, item in enumerate(events["value"]):
    #print("index:"+str(index))
      for ev in events['value']:
       event=getReadablEventDetails(ev)
       result_dict['result']['qa'].append(event)
       #print("eventNo:"+str(eventNo)+"eventId:"+event['id']+" subject:"+event['subject']+" organizer:"+event['organizer']+" startTime"+event['startTime']+" endTime"+event['endTime']+" location"+event['location'])
       eventNo+=1
         
      context.output.append(result_dict)
    else:
      print('No meetings on this day')
      context.output.append('No meetings on this day')


class create_my_event(Plugin):
 
    def execute (self,params,context,node_id):
        
        print('inside custom plugin meeting_time: '+params['meeting_time'])
        print('inside custom plugin meeting_duration: '+params['meeting_duration'])
        
        attendeesList = [x.strip() for x in params['participants_list'].split(',')]
        timeZone = "India Standard Time"
        meeting_durtion=params['meeting_duration']
        meeting_time=params['meeting_time'][0:19]
        startTime=datetime.datetime.strptime(meeting_time,"%Y-%m-%d %H:%M:%S")
        endTime = startTime + datetime.timedelta(minutes = getDurationInMins(meeting_durtion))
        
        startTime = startTime.isoformat()
        endTime =endTime.isoformat()
        print('startTime in custom:'+startTime)
        print('endTime in custom:'+endTime)
        
        event={}
        event['subject']=params['meeting_subject']
        event['content']=params['meeting_content']
        
        event['attendees']=[]
        
        for att in attendeesList:
            print('att::::::::::'+att)
            attendee={'name':att,'mail':att,'type':'required'}
            event['attendees'].append(attendee)
        
        event['startTime']=startTime
        event['endTime']=endTime
        event['timeZone']=timeZone
        location=params['meeting_location']
        event['location']=location
        eventJson = get_event_json(event)
  
        create_event(get_token(),eventJson)
        context.output.append("Meeting is scheduled")
        print('create my event executed suc')
        return SUCCESS, {}



class get_my_hosted_events_cancel(Plugin):
    def execute (self,params,context,node_id):
        action='cancel'
        get_my_hosted_events(self,params,context,node_id,action)
        print('get_my_hosted_events_cancel completed')
        return SUCCESS, {}

class get_my_hosted_events_res(Plugin):
    def execute (self,params,context,node_id):
        action='reschedule'
        params['meeting_cancel_datetime']=params['meeting_reschedule_search_date']
        get_my_hosted_events(self,params,context,node_id,action)
        print('get_my_hosted_events_reschedule completed')
        return SUCCESS, {}

class get_all_events(Plugin):
 
    def execute (self,params,context,node_id):
        print('get_all_events meeting_show_datetime:'+params['meeting_show_datetime'])
        time=getFormattedDateTime(params['meeting_show_datetime'])
        print("evts about to call")
        events=get_calenderView(get_token(),startTime=time['startTime'],endTime=time['endTime'])

        if ("400" in events)  or ("error" in events):
           print("error occured in get_all_event:"+events['error']['message'])
           context.output.append("error occured in get_all_event:"+events['error']['message'])
        elif(len(events['value'])>0):
          result_dict = {}
          result_dict['action'] = 'show'
          result_dict['result'] = {}
          result_dict['result']['result_type'] = 'qa'
          result_dict['result']['qa'] = []

          eventNo=1
          for ev in events["value"]:
           event=getReadablEventDetails(ev)
           result_dict['result']['qa'].append(event)
           #print("eventNo:"+str(eventNo)+"eventId:"+event['id']+" subject:"+event['subject']+" organizer:"+event['organizer']+" startTime"+event['startTime']+" endTime"+event['endTime']+" location"+event['location'])
           eventNo+=1
          context.output.append(result_dict)
          print('all events displayed:')
        else:
           print('No meetings on this day')
           context.output.append('No meetings on this day')
        return SUCCESS, {}


class cancel_my_event(Plugin):
 
    def execute (self,params,context,node_id):
        print('cancel_my_event meeting_cancel_id:'+params['meeting_cancel_id'])
        cancel_event(get_token(), params['meeting_cancel_id'])
        context.output.append('meeting cancelled')
        print('meeting cancelled')

        return SUCCESS, {}


class send_my_mail(Plugin):
 
    def execute (self,params,context,node_id):
        messageObj={}
        messageObj['subject']=params['email_subject']
        messageObj['content']=params['email_content']
        print("params['email_recipients']"+params['email_recipients'])
        messageObj['toRecipients']=[x.strip() for x in params['email_recipients'].split(',')]
        print("rec:"+json.dumps(messageObj['toRecipients']))
        msgJson=get_message_json(messageObj)
        response=send_mail(get_token(),msgJson)

        if ("400" in response)  or ("error" in response):
           print("error occured:"+response['error']['message'])
           context.output.append("error occured:"+response['error']['message'])
        else:
           print('mail sent')
           context.output.append('mail sent')
        return SUCCESS, {}

class reschedule_my_event(Plugin):
 
    def execute (self,params,context,node_id):
        meeting_res_id=params['meeting_reschedule_id']
        meeting_res_durtion=params['meeting_reschedule_duration']
        meeting_res_time=params['meeting_reschedule_datetime'][0:19]
        startTime=datetime.datetime.strptime(meeting_res_time,"%Y-%m-%d %H:%M:%S")
        endTime = startTime + datetime.timedelta(minutes = getDurationInMins(meeting_res_durtion))
        
        startTime = startTime.isoformat()
        endTime =endTime.isoformat()
        print('startTime in custom:'+startTime)
        print('endTime in custom:'+endTime)
        resEventJson=get_res_event_json(startTime,endTime)
        response=reschedule_event(get_token(),meeting_res_id,resEventJson)
        print("response::"+json.dumps(response))
        if ("400" in response)  or ("error" in response):
           print("error occured:"+response['error']['message'])
        else:
           print('meeting rescheduled')
     
        return SUCCESS, {}
        
#########################################################


