import warnings
import json
import io
import sys
import warnings

from de2.console import parse_args, show_context, handle_sys_event, handle_sys_engine_event, reload_engine, QuitException, ReloadException

def output_response(response):
    print()
    if response:
        for msg in response:
            if msg:
                if type(msg) is not dict:
                    print(msg)
                
                else:
                    if 'action' in msg and msg['action'] == 'choice':
                        continue

                    if 'prompt' in msg:
                        print(msg['prompt'])

                    if 'result' in msg:
                        if msg['result']['result_type'] == 'disambig':
                            for item in msg['result']['disambig']:
                                print(int(item[0]) + 1, ") " , item[1])

                        if msg['result']['result_type'] == 'wiki':
                            for result in msg['result']['wiki']:
                                print("----------")
                                print("----------")
                                print(result['title'])
                                print(result['url'])
                                
                        elif msg['result']['result_type'] == 'qa':
                            for result in msg['result']['qa']:
                                print("----------")
                                print("----------")
                                print(result['subject'])
                                print(result['organizer'])
                                #print(result['url'])

            print()

def run(**kwargs):
    warnings.filterwarnings(action='ignore')

    args = kwargs if "domain" in kwargs else vars(parse_args(sys.argv[1:]))
    domain_path = args.pop("domain")
    nlu = args.pop("nlu", "snips")
    nlu_path = args.pop("nlu_path", None)
    training_data = args.pop("training_data", None)

    context, engine = reload_engine(domain_path, nlu, nlu_path, training_data)

    while True:
        try:
            if sys.version_info[0] < 3:
                event = raw_input().strip()
            else:
                event = input().strip()
            # Handle sys events to by pass dialog engine and just make console
            # easier to work with
            if handle_sys_engine_event(event, engine, context):
                continue

            if handle_sys_event(event, context):
                continue
            
            response = engine.handle_event(event, context)
            output_response(response)
            
        except ReloadException:
            trace = context.trace
            context, engine = reload_engine(domain_path, nlu, nlu_path, training_data)
            context.trace = trace
        except QuitException:
            print("Goodbye...")
            return
        except Exception as e:
            print("Error:", str(e))
            print(traceback.format_exc())

if __name__ == '__main__':                    
    #run(domain = 'data/insurance/domain_insurance_townhall_script.yml')
    #run(domain = 'data/hr/domain_hr.yml')
    run(domain = 'data/tutorial.yml')
