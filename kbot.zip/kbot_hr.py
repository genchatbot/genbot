import warnings
import json
import io
import os
import copy
import subprocess
import requests

import numpy as np
import collections
from pprint import pprint
import datetime

from pyo365 import Account

from de2 import load_from_file, DialogEngine, Context
from de2.domain import Plugin
from de2.constants import *

from faq_runtime import FaqRuntime


#PLATFORM = "hr"
FAQ_PROBABILITY_THRESHOLD = 0.4
MAX_FAQ_RESULTS = 3
MAX_FAQ_RESULTS_FROM_SERVICE = 20

S3_LOG_UPLOAD_NUM_FILES = 20
S3_BUCKET_PATH = 's3://genesysappliedresearch.com/hrbot-india-query-logs'


# try:
#     faqObjWiki = FaqRuntime(PLATFORM)
# except ValueError:
#     faqObjWiki = None

FAQ_URI = "https://qna-aip.jopaws.com/api/v1/models/09de2817250c46368ae70c1d3243f11e/answers"


class reset_kb_state(Plugin):

    def dump_logs(self, context):        
        
        if 'answer_accepted' in context.slots and context.slots['answer_accepted'] == 'yes' and 'feedback_results_1' not in context.kbot_log:
            context.kbot_log['feedback_results_1'] = "1"
        elif 'answer_accepted' in context.slots and context.slots['answer_accepted'] == 'yes' and context.kbot_log['feedback_results_1'] == "0":
            context.kbot_log['feedback_results_2'] = "1"
        elif 'answer_accepted' in context.slots and context.slots['answer_accepted'] == 'no':
            context.kbot_log['feedback_results_2'] = "0"
        
        if 'answer_accepted' in context.slots and context.slots['answer_accepted'] == 'no' and 'get_hr_response' not in context.kbot_log:
            context.kbot_log['get_hr_response'] = "0"
        if 'answer_accepted' not in context.slots and 'get_hr_response' not in context.kbot_log:
            context.kbot_log['get_hr_response'] = "0"

        context.kbot_log['system_confidence_theshold'] = FAQ_PROBABILITY_THRESHOLD
        context.kbot_log['system_max_faq_results'] = MAX_FAQ_RESULTS                

        query_id = datetime.datetime.now().strftime('%YY%mM%dD_%HH%MM%SS%fuS')
        json_dump_data = {query_id: context.kbot_log}
        #pprint(json_dump_data)


        # Dumping the session log to local file
        if not os.path.exists("logs"):
            os.makedirs("logs")        
        json.dump(json_dump_data, open(os.path.join("logs", "query_log_" + query_id + ".json"), 'w'), indent=4)                

        
        ######## For S3 upload of logs ########

        if len(os.listdir('logs')) % S3_LOG_UPLOAD_NUM_FILES != 0:
            return

        # Zipping and uploading logs to S3 for every S3_LOG_UPLOAD_NUM_FILES sessions
        if not os.path.exists("tmp"):
            os.makedirs("tmp")                    
        zip_file_name = os.path.join("tmp", "hrbotindia_logs_" + query_id + ".zip")
        try:
            subprocess.call(['zip', '-r', zip_file_name, 'logs'])
            subprocess.call(['aws', 's3', 'sync', 'tmp', S3_BUCKET_PATH])
            subprocess.call(['rm', '-rf', zip_file_name])
            subprocess.call('rm logs/*', shell=True)
        except:
            print("subprocess call failed")
            pass        
        
        ########################################

        return



    def execute(self, params, context, node_id):
        
        self.dump_logs(context)

        output = []
        if context.output:
            output = context.output

        context.reset()        

        if output:
            context.output = output

        if hasattr(context, 'category_options') and context.category_options:
            print("context reset not happening properly.. manually resetting context.category_options")
            context.category_options = None
        
        return SUCCESS, {}



class search_faq(Plugin):                

    def execute(self, params, context, node_id):        

        context.kbot_log = {'original_query' : params['query']}
        
        print("In search_faq execute")
        if params['kb_type'] == 'faq':
            context.slots['faq_active_type'] = 'faq'
            try:                              
                response = requests.post(FAQ_URI,
                    data = json.dumps({
                                "query": params['query'], 
                                "numResults": MAX_FAQ_RESULTS_FROM_SERVICE, 
                                "confidenceThreshold": FAQ_PROBABILITY_THRESHOLD
                            }),
                    headers = {
                        "accept": "application/json", 
                        "Content-Type": "application/json"
                    }                
                )
                response.raise_for_status()
                faqAnswers = json.loads(response.text)['entities']            
            except:
                print("Error while making request to the FAQ Service")
                return FAILURE, {}        
                
        pprint(faqAnswers)
        if len(faqAnswers) == 0 or faqAnswers[0]['confidence'] < FAQ_PROBABILITY_THRESHOLD:
            return FAILURE, {}           
                        
        context.faq_articles = faqAnswers        
        
        return SUCCESS, []



class display_faq_answers(Plugin):

    def to_json(self, context):
        result_dict = {}
        if not hasattr(context, 'faq_articles') or not context.faq_articles:
            return result_dict

        result_dict['kb_type'] = context.slots['faq_active_type']
        result_dict['action'] = 'boolean'

        result_dict['result'] = {}
        result_dict['result']['result_type'] = 'qa'
        result_dict['result']['qa'] = []
        for answer in context.faq_articles[0:MAX_FAQ_RESULTS]:
            qa_dict = {}
            if answer['confidence'] > FAQ_PROBABILITY_THRESHOLD:                
                #qa_dict['answer'] = " ".join(filter(lambda x:x[0]!='@', qa_dict['answer'].split())) #removes usernames from community posts beginning with @                
                qa_dict['answer'] = answer['answer'].replace('. ', ".<br>")                
                #qa_dict['question'] = answer['question'].lstrip('0123456789.- ')  # removes the initial numbering
                qa_dict['question'] = answer['question']
                qa_dict['url'] = answer['url'] if 'url' in answer and answer['url'].strip() else "https://www.genesys.com"
                qa_dict['category'] = answer['category'][0] if 'category' in answer else ""
                qa_dict['id'] = answer['id']
                qa_dict['probability'] = answer['confidence']
                result_dict['result']['qa'].append(qa_dict)

        if context.slots['faq_active_type'] == 'faq':          
            result_dict['prompt'] = "Let's see if any of these frequently asked questions address your query:"  
            return result_dict


    def execute(self, params, context, node_id):
        #print("In display_faq_answers.execute()")
        if not hasattr(context, 'faq_articles') or not context.faq_articles or len(context.faq_articles) == 0:
            return FAILURE, {}        

        if  context.faq_articles[0]['confidence'] < FAQ_PROBABILITY_THRESHOLD:
            print("Conf = {:.4f}".format(context.faq_articles[0]['confidence']))
            print("Conf < theshold. No disambiguation. Returning")            
            if 'results_shown_1' not in context.kbot_log:
                context.kbot_log['results_shown_1'] = []
            elif 'results_shown_2' not in context.kbot_log:
                context.kbot_log['results_shown_2'] = []            
            return FAILURE, {}

        result_dict = self.to_json(context)       
        context.result_dict = result_dict 
        context.output.append(result_dict)
        pprint(result_dict)

        if 'results_shown_1' not in context.kbot_log:
            context.kbot_log['results_shown_1'] = result_dict['result']['qa']
        elif 'results_shown_2' not in context.kbot_log:
            context.kbot_log['results_shown_2'] = result_dict['result']['qa']
        else:
            print("both result log entries filled.. something off")
        #pprint(context.kbot_log)

        return SUCCESS, {}
        


class ask_disambiguation_category(Plugin):

    def to_json(self, options, context):
        result_dict = {}

        result_dict['kb_type'] = ''
        result_dict['action'] = 'choice'
        result_dict['prompt'] = "Could you please specify the category from below?"
        result_dict['result'] = {}
        result_dict['result']['result_type'] = 'disambig'
        result_dict['result']['disambig'] = []
        for index, opt in enumerate(options):
            result_dict['result']['disambig'].append({str(index) : opt})
        return result_dict


    def execute(self, params, context, node_id):

        context.kbot_log['feedback_results_1'] = "0"

        if hasattr(context, 'category_options') and context.category_options:
            print("category options already shown.. returning the old values")
            return SUCCESS, [context.category_options]

        if not context.faq_articles or len(context.faq_articles) <= MAX_FAQ_RESULTS:
            return FAILURE, {}

        if  context.faq_articles[MAX_FAQ_RESULTS]['confidence'] < FAQ_PROBABILITY_THRESHOLD:
            print("Conf = {:.4f}".format(context.faq_articles[MAX_FAQ_RESULTS]['confidence']))
            print("Conf < theshold. No disambiguation")
            return FAILURE, {}
        
        context.faq_articles = context.faq_articles[MAX_FAQ_RESULTS:] # omitting the first 3 FAQs already displayed

        print("Num FAQ results: {}".format(len(context.faq_articles)))
        pprint(context.faq_articles[:MAX_FAQ_RESULTS])

        category_dict = {}        
        for answer in context.faq_articles:                           
            if answer['category'][0] not in category_dict:
                category_dict[answer['category'][0]] = 1
            else:
                category_dict[answer['category'][0]] += 1
        #pprint(category_dict)
        sorted_cat_dict_as_tuples = sorted(category_dict.items(), key=lambda x:x[1], reverse=True)
        pprint(sorted_cat_dict_as_tuples)
        
        options = list(list(zip(*sorted_cat_dict_as_tuples))[0])        
        print("options")
        print(options)
        if len(options) > 3:        
            options = options[:3] + ["OTHERS"]
        else:
            options = options + ["OTHERS"]
        print("options")
        print(options)
        # for answer in context.faq_articles:
        #     if answer['category'][0] not in options[0:3]:
        #         if  answer['probability'] < FAQ_PROBABILITY_THRESHOLD:
        #             options = options[0:3]   # removing "OTHERS"
        #         break

                                                
        #options = list(list(zip(*sorted_cat_dict_as_tuples))[0])[:3] + ["OTHERS"]        
        context.category_options = options
        context.kbot_log['category_options_shown'] = options

        result_dict = self.to_json(options, context)
        pprint(result_dict)
        context.output.append(result_dict)                                    
        return SUCCESS, [options]              



class filter_results(Plugin):

    def execute(self, params, context, node_id):

        if 'category' not in params or not context.faq_articles or not hasattr(context, 'category_options'):
            return FAILURE, {}

        print("category: {}".format(params['category']))        
        category = params['category']

        context.kbot_log['category_chosen'] = category

        faq_articles_filtered = []
        if category != "OTHERS":        
            faq_articles_filtered = [answer for answer in context.faq_articles if answer['category'][0] == category]            
        else:
            faq_articles_filtered = [answer for answer in context.faq_articles if answer['category'][0] not in context.category_options]            
        context.faq_articles = faq_articles_filtered 
        print("#Filtered FAQs: {}".format(len(context.faq_articles)))       
        return SUCCESS, {}



class verify_email(Plugin):        

    def execute(self, params, context, node_id):

        email = context.slots['msg']
        print(email)        
        if not email.strip() or '@' not in email or len(email.strip().lower().split('@')) != 2 or not email.strip().lower().split('@')[0].strip() or email.strip().lower().split('@')[1] != "genesys.com":                        
            context.output.append("This doesn't seem to be a valid Genesys email id. Could you please re-enter your email id?") 
            return RUNNING, {}

        context.slots['email_id'] = email
        return SUCCESS, {}



class send_email(Plugin):      

    def get_mail_body(self, params, context):

        if 'reframed_query' in params and params['reframed_query']:
            reframed_query = params['reframed_query']
            context.kbot_log['reframed_query'] = reframed_query
        else:
            reframed_query = None

        original_query = params['query']
        customer_email = params['email']
        customer_name = params['customer_name']

        mail_body = "Hello HRD-India, <br><br>"
        mail_body += "A query has been raised which requires your response. Please find the details below: <br><br>"
        #mail_body += "<p class=MsoNormal><span lang=EN-IN><o:p>&nbsp;</o:p></span></p>"
        
        mail_body += "<ul style='margin-top:0cm' type=disc><li class=MsoListParagraph style='margin-left:0cm;mso-list:l2 level1 lfo2'><span lang=EN-IN>"
        mail_body += "<b>Name: </b>" + customer_name + "<o:p></o:p></span></li>"
        mail_body += "<li class=MsoListParagraph style='margin-left:0cm;mso-list:l2 level1 lfo2'><span lang=EN-IN>"        
        mail_body += "<b>E-mail: </b>" + "<a href=\"mailto:" + customer_email + "\"><span style='color:windowtext;text-decoration:none'>" + customer_email + "</span></a>" + "<o:p></o:p></span></li>"
        mail_body += "<li class=MsoListParagraph style='margin-left:0cm;mso-list:l2 level1 lfo2'><span lang=EN-IN>"
        if reframed_query:
            mail_body += "<b>Query: </b>&quot;<span style='color:red'>" + reframed_query + "</span>&quot;<o:p></o:p></span></li>"
        else:
            mail_body += "<b>Query: </b>&quot;<span style='color:red'>" + original_query + "</span>&quot;<o:p></o:p></span></li>"
        mail_body += "</ul><br>"
                
        mail_body += "------------------------------------------------------------------<o:p></o:p></span></p>"        
        
        mail_body += "<p class=MsoNormal><b><u><span lang=EN-IN>"
        mail_body += "G-Bot chat log:<o:p></o:p></span></u></b></p>"        
    
        mail_body += "<ol style='margin-top:0cm' start=1 type=1>"
        mail_body += "<li class=MsoListParagraph style='margin-left:0cm;mso-list:l1 level1 lfo3'><span lang=EN-IN>"
        mail_body += "Original question: &quot;" + context.kbot_log['original_query'] + "&quot;<o:p></o:p></span></li><br><br>"
                        
        if 'results_shown_1' in context.kbot_log and len(context.kbot_log['results_shown_1']) > 0:
            mail_body += "<li class=MsoListParagraph style='margin-left:0cm;mso-list:l1 level1 lfo3'><span lang=EN-IN>"
            mail_body += "Initial FAQs shown: <o:p></o:p></span></li>"
            mail_body += "<ol style='margin-top:0cm' start=1 type=a>"
            for result in context.kbot_log['results_shown_1']:
                mail_body += "<li class=MsoListParagraph style='margin-left:0cm;mso-list:l1 level2 lfo3'><span lang=EN-IN>"                
                mail_body += result['question'] + "<o:p></o:p></span></li>"
            mail_body += "</ol>"
        else:
            mail_body += "<li class=MsoListParagraph style='margin-left:0cm;mso-list:l1 level1 lfo3'><span lang=EN-IN>"
            mail_body += "Initial FAQs shown: None" + "<o:p></o:p></span></li><br>"
        
        if 'category_options_shown' in context.kbot_log and len(context.kbot_log['category_options_shown']) > 0:
            mail_body += "<br><li class=MsoListParagraph style='margin-left:0cm;mso-list:l1 level1 lfo3'><span lang=EN-IN>"            
            mail_body += "Categories shown: <o:p></o:p></span></li>"
            mail_body += "<ol style='margin-top:0cm' start=1 type=a>"
            for c in context.kbot_log['category_options_shown']:
                mail_body += "<li class=MsoListParagraph style='margin-left:0cm;mso-list:l1 level2 lfo3'><span lang=EN-IN>"
                mail_body += c + "<o:p></o:p></span></li>"
            mail_body += "</ol><br>"            
        
        if 'category_chosen' in context.kbot_log and context.kbot_log['category_chosen'].strip():
            mail_body += "<li class=MsoListParagraph style='margin-left:0cm;mso-list:l1 level1 lfo3'><span lang=EN-IN>"
            mail_body += "Category chosen: &quot;" + context.kbot_log['category_chosen'] + "&quot;<o:p></o:p></span></li><br>"
        
        if 'results_shown_2' in context.kbot_log and len(context.kbot_log['results_shown_2']) > 0:
            mail_body += "<br><li class=MsoListParagraph style='margin-left:0cm;mso-list:l1 level1 lfo3'><span lang=EN-IN>"
            mail_body += "Final FAQs shown: " + "<o:p></o:p></span></li>"
            mail_body += "<ol style='margin-top:0cm' start=1 type=a>"
            for result in context.kbot_log['results_shown_2']:
                mail_body += "<li class=MsoListParagraph style='margin-left:0cm;mso-list:l1 level2 lfo3'><span lang=EN-IN>"
                mail_body += result['question'] + "<o:p></o:p></span></li>"
            mail_body += "</ol><br>"
        else:
            mail_body += "<br><li class=MsoListParagraph style='margin-left:0cm;mso-list:l1 level1 lfo3'><span lang=EN-IN>"            
            mail_body += "Final FAQs shown: None" + "<o:p></o:p></span></li><br><br>"

        if reframed_query:
            mail_body += "<li class=MsoListParagraph style='margin-left:0cm;mso-list:l1 level1 lfo3'><span lang=EN-IN>"
            mail_body += "Reframed question: &quot;" + reframed_query + "&quot;<o:p></o:p></span></li>"
        else:
            mail_body += "<li class=MsoListParagraph style='margin-left:0cm;mso-list:l1 level1 lfo3'><span lang=EN-IN>"
            mail_body += "Reframed question: None" + "<o:p></o:p></span></li>"
        mail_body += "</ol>"            
        
        mail_body += "------------------------------------------------------------------<o:p></o:p></span></p>"
        
        mail_body += "<p class=MsoNormal><span lang=EN-IN>"        
        mail_body += "Regards,<br>"
        mail_body += "Yours truly,<br>"
        mail_body += "G-Bot" 
        mail_body += "<o:p></o:p></span></p>"

        return mail_body


    def execute(self, params, context, node_id):

        context.kbot_log['get_hr_response'] = "1"      
        
        try:                    
            credentials = ('0ef5f2d6-b2b4-4b87-b954-00b851b9c80a', 'vsmPAO9228xhclSJSE4)@}@')   # HrBotIndia@genesys.com credentials
            account = Account(credentials=credentials)                
            m = account.new_message()                             
        
            recepient_email = 'HrBotIndia@genesys.com'
            m.to.add(recepient_email)                            
            m.subject = "G-Bot: Query from " + params['customer_name']
            m.body = self.get_mail_body(params, context)
            m.send()            
            print("Email sent")        
        except:
            print("Sending email failed")

        return SUCCESS, {}