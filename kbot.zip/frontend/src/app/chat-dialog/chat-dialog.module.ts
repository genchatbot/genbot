import { NgModule } from '@angular/core';
import {ChatDialogComponent} from './chat-dialog.component';
import {AppSharedModule} from '../shared/shared.module';

@NgModule({
  imports: [AppSharedModule],
  declarations: [ChatDialogComponent],
  exports: [ChatDialogComponent],
  providers: [],
})
export class ChatDialogModule {}
