import { AfterViewInit, Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import {ChatSession, ChatTurn, KbotTurn, SystemTurn} from '../shared/models/index';
import {ChatService} from '../shared/services/chat.service';

@Component({
  selector: 'app-chat-dialog',
  templateUrl: './chat-dialog.component.html',
  styleUrls: ['./chat-dialog.component.scss'],
})
export class ChatDialogComponent implements OnInit, AfterViewInit {
  @ViewChild('msgArea')
  msgArea;
  session: ChatSession;
  turns: ChatTurn[];
  chatText = '';
  expectedResponse = {options: false};
  turnCount = 0;
  showModal = false;
  modalText = null;
  showAgentTransfer = false;
  @Output()
  updatedTurn = new EventEmitter();

  constructor(private chatService: ChatService) {
    this.session = this.chatService.chat_session;
  }

  ngOnInit() {
   // this.logger.debug('chat sessions', this.session);
  }

  ngAfterViewInit() {
    // this.scrollToLastMsg();
  }

  scrollToLastMsg() {
    this.msgArea.nativeElement.scrollTop = this.msgArea.nativeElement.scrollHeight;
  }

  newSession() {
      this.turnCount = 0;
      this.showAgentTransfer = false;
      this.chatService.createSession(null, null).subscribe(
        (response: any) => {
          this.turns = [];
          this.updatedTurn.emit({});
        },
        error => {
          alert(error);
        }
      );
  }

  closeSession() {
    this.session.session_active = false;
    this.showModal = false;
    this.showAgentTransfer = false;


  }

  processResponseBool(answer: string, event) {
    console.log('responded: ' + answer);
    const span = event.srcElement.parentElement;
   // span.style.animation = 'fadeOut 2s';
    span.style.display = 'none';

    this.userTurn(answer);
  }

  processResponseChoice(choice: string, event) {
    console.log('responded: ' + choice);
    const span = event.srcElement.parentNode.parentElement;
    span.style.display = 'none';
    this.userTurn(choice);
  }

  showAnswerModal(resp: any) {
    const obj = resp;
    if (obj.snippet) {
      const snip1 = resp.snippet.replace(/"/g, '');
      const snip = snip1.replace(/\|/g, ' ...\r\n\n ');
      obj.question = 'Page Title: ' + resp.title;
      obj.answer = snip;
      this.modalText = obj;
      this.showModal = true;
    } else {
      const res = obj.answer.replace(/<br>/g, ' \r\n\n ');
      obj.answer = res;
      this.modalText = obj;
      this.showModal = true;
    }
  }
  clearModal() {
    this.showModal = false;

  }

  userTurn(message) {
    message = message.trim();
    if (message.length === 0) {
      return;
    }
    const newTurn: ChatTurn = { is_system: false, system: null, kbot: null,
      msg: message, faqList: null, wiki: null, disambig: null, prompt: undefined };
    this.turns.push(newTurn);
    this.turnCount++;
    this.chatText = '';
    this.scrollToLastMsg();
    if (this.turnCount >= 4) {
      this.showAgentTransfer = true;
   }
    // this.showAgentTransfer = this.turnCount >= 4;


      this.chatService.processTurn(message, this.turnCount).subscribe(
      (response: KbotTurn) => {
        const sysTurn: ChatTurn = { is_system: true, kbot: response, system: null,
          msg: response.result ? response.result.result_type : null,
          faqList: response.result ? response.result.qa : null, wiki: response.result ? response.result.wiki : null,
          disambig: response.result ? response.result.disambig : null, prompt: response.prompt};
        this.turns.push(sysTurn);
        this.updatedTurn.emit(response);
    //    this.scrollToLastMsg();
      },
      error => {
        throw new Error(error);
      },
      () => {
        setTimeout(() => {
          this.scrollToLastMsg();
        }, 100);
      }
    );
  }
}
