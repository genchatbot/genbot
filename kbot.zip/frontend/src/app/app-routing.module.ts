import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {ChatDialogComponent} from './chat-dialog/chat-dialog.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/kbot',
    pathMatch: 'full',
  },
  {
    path: 'kbot',
    component: ChatDialogComponent,
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
