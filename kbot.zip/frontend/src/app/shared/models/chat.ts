export class ChatSession {
  session_active: boolean = false;
  session_id: string = '';
}

// tslint:disable-next-line:max-classes-per-file
export class ChatTurn {
  is_system: boolean = false;
  system: SystemTurn = undefined;
  kbot: KbotTurn = undefined;
  msg: string = undefined;
  faqList: any[] = undefined;
  wiki: any[] = undefined;
  disambig: any[] = undefined;
  prompt: string = undefined;

}

export class KbotTurn {
  // prompt: string;
  faqList: any[] = undefined;
  wiki: any[] = undefined;
  disambig: any = undefined;
  result: any = undefined;
  kb_type: string = undefined;
  prompt: string = undefined;
  constructor(obj?: any) {
    for (const field in obj) {
      if (this.hasOwnProperty(field)) {
        this[field] = obj && obj[field];
      }
    }
  }
}

// tslint:disable-next-line:max-classes-per-file
export class SystemTurn {
  intent: any;
  slots: any;
  state: [
    'expect_nl_input',
    'expect_yes_no',
    'expect_slot_value',
    'agent_escalation',
    'failure',
    'goal_reached',
    'error'
  ];
  transcript: string;

  constructor(obj?: any) {
    for (const field in obj) {
      if (this.hasOwnProperty(field)) {
        this[field] = obj && obj[field];
      }
    }
  }
}
