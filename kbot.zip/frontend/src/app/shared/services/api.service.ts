import { Injectable } from '@angular/core';
import {environment} from '../../../environments/environment';

@Injectable()
export class ApiService {
  url: string = undefined;
  mock: boolean = false;

  constructor() {
    this.url = environment.API_URL;
    this.mock = environment.mock;
  }
}
