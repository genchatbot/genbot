import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { ChatSession } from '../models/chat';
import { ApiService } from '../services/api.service';

export interface DialogSessionResponse {
  ok: boolean;
  item: any;
}

export interface ChatSessionResponse {
  // prompts: boolean;
  id: any;
}

export class ChatSessionResponse {
  turn_id: number = undefined
  result: any = undefined
  kb_type: string = undefined;
  prompt: string = undefined;
}

@Injectable()
export class ChatService {
  chat_session: ChatSession;

  constructor(private http: HttpClient, private api: ApiService) {
    this.resetSession();
  }

  // TOD  can we avoid duplication of mock just because GET instead of POST?
  createSessionMock(domain_id: string, model_id: string) {
    return this.http.get([this.api.url, 'dialog_sessions'].join('/')).pipe(
      map((res: DialogSessionResponse) => {
        if (res.ok && res.item.id) {
          this.chat_session.session_id = res.item.id;
          this.chat_session.session_active = true;
          return res.item.id;
        } else {
          throw new Error('Not Acceptable Response');
        }
      })
    );
  }

  createSession(domain_id: string, model_id: string) {
    this.chat_session.session_active = false;
    if (this.api.mock) {
      return this.createSessionMock(domain_id, model_id);
    }

    return this.http.post([this.api.url, 'dialogs'].join('/'), { domain_id, model_id }).pipe(
      map((res: ChatSessionResponse) => {
        if (res.id) {
          this.chat_session.session_id = res.id;
          this.chat_session.session_active = true;
          return res.id;
        } else {
          throw new Error('Not Acceptable Response');
        }
      })
    );
  }

  resetSession() {
    this.chat_session = new ChatSession();
  }

  processTurnMock(input: string, turn: number) {
    const api_path = 'dialog_session_1';
    const api_path2 = 'dialog_chat_' + turn;

    return this.http.post([this.api.url, 'dialogs', this.chat_session.session_id].join('/'), { 'input': input }).pipe(
      map((res: ChatSessionResponse) => {
        if (res.result && res.result.result_type) {
          return res;
        } else if (res.prompt) {
          return res;
        } else {
          throw new Error('Not Acceptable Response');
        }
      })
    );
  }

  processTurn(input: string, turn: number) {
    const api_path = 'dialog_sessions';
    const turn1 = 'dialog_chat_1';
    const turn2 = 'dialog_chat_2';
    const turn3 = 'dialog_chat_3';
    const turn4 = 'dialog_chat_4';

    if (!this.api.mock) {
      return this.processTurnMock(input, turn);
    }

    return this.http
      .put([this.api.url, api_path, this.chat_session.session_id].join('/'), { input: { transcript: input } })
      .pipe(
        map((res: DialogSessionResponse) => {
          if (res.ok && res.item.output) {
            return res.item.output;
          } else {
            throw new Error('Not Acceptable Response');
          }
        })
      );
  }
}
