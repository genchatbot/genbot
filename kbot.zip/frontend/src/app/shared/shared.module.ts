import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
// import { TextInputHighlightModule } from 'angular-text-input-highlight';

// import { AutoCompleteModule } from 'primeng/autocomplete';
// import { CheckboxModule } from 'primeng/checkbox';
/* import { DialogModule } from 'primeng/dialog';
import { DropdownModule } from 'primeng/dropdown';
import { FileUploadModule } from 'primeng/fileupload';
import { InputTextModule } from 'primeng/inputtext';
import { MultiSelectModule } from 'primeng/multiselect';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { PaginatorModule } from 'primeng/paginator';
import { RadioButtonModule } from 'primeng/radiobutton';
import { TableModule } from 'primeng/table';
import { TabViewModule } from 'primeng/tabview';
import { ToastModule } from 'primeng/toast';
import { ToggleButtonModule } from 'primeng/togglebutton'; */

// import { NgxChartsModule } from '@swimlane/ngx-charts';

// import { FormControlModule } from '~app/shared/modules/form-control/form-control.module';

/*const primengModules = [
  AutoCompleteModule,
  ToastModule,
  InputTextModule,
  DropdownModule,
  FileUploadModule,
  OverlayPanelModule,
  RadioButtonModule,
  CheckboxModule,
  TableModule,
  TabViewModule,
  PaginatorModule,
  ToggleButtonModule,
  MultiSelectModule,
  DialogModule,
]; */

@NgModule({
  imports: [CommonModule, RouterModule, FormsModule, ReactiveFormsModule],
  declarations: [],
  exports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    RouterModule,
  //  FormControlModule,
   // TextInputHighlightModule,
   // ...primengModules,
  ],
  providers: [],
  entryComponents: [],
})
export class AppSharedModule {}
