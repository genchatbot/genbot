export const environment = {
  production: false,
  mock: false,
  API_URL: 'http://pcn-cent7-cn21.ininlab.com:8085/api/v1'
};
