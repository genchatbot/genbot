import warnings
from de2.console import *
import traceback
import argparse
import sys
import json
from tutorial.authhelper import get_token_from_code,get_access_token,get_token_from_refresh_token
from tutorial.utils import write_token

# 2018-09-03 felixw
#
# Very simple Flask API for dialog engine.
# Specify listen port with RASA_DE_REST_API_PORT environment variable. Default: 8080
#
from flask import Flask
from flask import request
from flask import jsonify
from flask import abort
import uuid
import os
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

class Session:
    def __init__(self, id, engine):
        self.id = id
        self.turn_count = 0
        self.engine = engine
        self.context = Context()

    def get_introduction(self):
        return(self.engine.handle_event('__INIT__', self.context))
        # return self.engine.introduction(self.context)

    def handle_event(self, event):
        return self.engine.handle_event(event, self.context)

g_api_sessions = {}
g_dialog_engine = None
AGENT_CALL_ESCALATION_COUNT = 3

@app.route('/api/v1/dialogs', methods=['POST', 'GET'])
def post_dialogs_create():
    body = request.get_json()
    
    # Either caller can provide an ID or we creat an UUID for them
    id = body['id'] if body and ('id' in body) else str(uuid.uuid4())
    if id in g_api_sessions:
        abort(400)

    if g_dialog_engine is None:
        abort(500)
    
    session = Session(id, g_dialog_engine)
    g_api_sessions[session.id] = session

    result = {
        'id': session.id,
        'prompts': [session.get_introduction()]
    }
    return jsonify(result)

@app.route('/api/v1/dialogs/<string:dialogid>', methods=['POST'])
def post_dialogs_handle_event(dialogid):
    if not dialogid in g_api_sessions:
        abort(404)
    session = g_api_sessions[dialogid]

    body = request.get_json()
    if not body:
        abort(415)

    if not 'input' in body:
        abort(400)

    utterance = body['input']
    session.turn_count += 1
    response = session.handle_event(utterance)
    call_agent = False
    if (session.turn_count >= AGENT_CALL_ESCALATION_COUNT):
        call_agent = True

    print("utterance server.py::"+utterance)
    print("response in server.py::"+json.dumps(response))
    if response:        
        if type(response[0]) is dict:
            print("response[0] is dict")
            result = response[0]
            result['id'] = session.id,
            result['input'] = utterance
            result['turn_count'] = session.turn_count,
            result['call_agent'] = call_agent,            
        else:
            print("response[0] is not dict")
            result = {
                'id': session.id,
                'prompt': response[0],
                'input': utterance,
                'turn_count': session.turn_count,
                'call_agent' : call_agent,
                'chat_status': 0
            }
        return jsonify(result)
    else:
        result = {
            'id': session.id,
            'prompt': [],
            'input': utterance,
            'turn_count': session.turn_count,
            'call_agent': call_agent
        }
        return jsonify(result)    

@app.route('/api/v1/dialogs/<string:dialogid>', methods=['DELETE'])
def post_dialogs_delete(dialogid):
    if not dialogid in g_api_sessions:
        abort(404)
    del g_api_sessions[dialogid]
    return jsonify({})


@app.route('/api/v1/healthcheck', methods=['GET'])
def get_healthcheck():
    return jsonify({'Http-Status':200, 'Healthy': g_dialog_engine is not None})

@app.route('/api/v1/token', methods=['POST', 'GET'])
def gettoken():
  print("inside  gettoken")
  
  auth_code = request.GET['code']
  redirect_uri = "http://10.145.2.193:8085/api/v1/token";
  token = get_token_from_code(auth_code, redirect_uri)
  access_token = token['access_token']
  print("access token:"+access_token)
  write_token(access_token)

def server(**kwargs):
    warnings.filterwarnings(action='ignore')

    args = kwargs if "domain" in kwargs else vars(parse_args(sys.argv[1:]))
    domain_path = args.pop("domain")
    nlu = args.pop("nlu", "snips")
    nlu_path = args.pop("nlu_path", None)
    training_data = args.pop("training_data", None)

    context, engine = reload_engine(domain_path, nlu, nlu_path, training_data)

    global g_dialog_engine
    g_dialog_engine = engine
    # app.run(host='0.0.0.0', port=int(os.getenv('RASA_DE_REST_API_PORT', '8080')))
    app.run(host='0.0.0.0', port=int('8085'))
    #app.run(host='127.0.0.1', port=8080)
    return

if __name__ == '__main__':    
    #server(domain = 'data/insurance/domain_insurance_townhall_script.yml')
    #server(domain = 'data/hr/domain_hr.yml')
    server(domain = 'data/tutorial.yml')
